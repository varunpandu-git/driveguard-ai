import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Eye, EyeOff, Wind, Phone, ShieldCheck, ShieldAlert, RotateCw,
  Activity, Clock, Gauge, Bell, AlertTriangle, CheckCircle2, Radio,
} from 'lucide-react';
import CameraScan from '@/components/CameraScan';
import Reveal from '@/components/Reveal';

type Status = 'safe' | 'warning' | 'danger';

interface Metric {
  icon: typeof Eye;
  label: string;
  value: string;
  status: Status;
}

const statusColor: Record<Status, string> = {
  safe: 'text-success bg-success/15 ring-success/30',
  warning: 'text-warning bg-warning/15 ring-warning/30',
  danger: 'text-danger bg-danger/15 ring-danger/30',
};
const statusDot: Record<Status, string> = {
  safe: 'bg-success', warning: 'bg-warning', danger: 'bg-danger',
};

const sampleAlerts = [
  { type: 'Phone detected', level: 'danger' as Status, time: 'now' },
  { type: 'Eyes off road 2.1s', level: 'warning' as Status, time: '12s' },
  { type: 'Yawning detected', level: 'warning' as Status, time: '48s' },
  { type: 'Seat belt fastened', level: 'safe' as Status, time: '1m' },
  { type: 'Attentive', level: 'safe' as Status, time: '1m 30s' },
];

function useTicker(intervalMs: number) {
  const [, setTick] = useState(0);
  useEffect(() => {
    const id = setInterval(() => setTick((t) => t + 1), intervalMs);
    return () => clearInterval(id);
  }, [intervalMs]);
}

export default function LiveDashboard() {
  useTicker(1500);
  const now = Date.now();
  const phase = (now / 1500) % 6;

  const [tripStart] = useState(() => Date.now() - 184_000);
  const elapsed = Math.floor((Date.now() - tripStart) / 1000);
  const mm = String(Math.floor(elapsed / 60)).padStart(2, '0');
  const ss = String(elapsed % 60).padStart(2, '0');

  const distraction = phase < 1 ? 'Phone Use' : phase < 2 ? 'Drowsy' : phase < 3 ? 'Looking Away' : 'Attentive';
  const driverStatus: Status = phase < 3 ? (phase < 1 ? 'danger' : 'warning') : 'safe';
  const eyeOpen = phase >= 1.5 && phase < 2.2 ? false : true;
  const yawning = phase >= 2 && phase < 2.5;
  const phone = phase < 1;
  const belt = true;
  const headDir = phase < 3 ? ['Right', 'Down', 'Left'][Math.floor(phase)] : 'Forward';
  const confidence = (88 + Math.sin(now / 700) * 6).toFixed(1);
  const fps = (29 + Math.sin(now / 500) * 1.4).toFixed(0);
  const risk = phase < 1 ? 82 : phase < 2 ? 61 : phase < 3 ? 54 : 14;

  const metrics: Metric[] = [
    { icon: Eye, label: 'Eye Status', value: eyeOpen ? 'Open' : 'Closed', status: eyeOpen ? 'safe' : 'danger' },
    { icon: Wind, label: 'Yawning', value: yawning ? 'Detected' : 'None', status: yawning ? 'warning' : 'safe' },
    { icon: Phone, label: 'Phone Detection', value: phone ? 'In use' : 'Clear', status: phone ? 'danger' : 'safe' },
    { icon: belt ? ShieldCheck : ShieldAlert, label: 'Seat Belt', value: belt ? 'Fastened' : 'Off', status: belt ? 'safe' : 'danger' },
    { icon: RotateCw, label: 'Head Direction', value: headDir, status: phase < 3 ? 'warning' : 'safe' },
  ];

  return (
    <div className="mx-auto max-w-7xl px-6 py-8">
      <Reveal className="mb-8 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-cyan-glow">
            <Radio className="h-4 w-4 animate-pulse" />
            <span className="font-display text-sm font-semibold uppercase tracking-widest">Live</span>
          </div>
          <h1 className="mt-1 font-display text-3xl font-bold">Driver Monitoring Dashboard</h1>
        </div>
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-2 rounded-xl glass px-4 py-2 text-sm">
            <Clock className="h-4 w-4 text-cyan-glow" /> Trip {mm}:{ss}
          </span>
          <span className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-brand-500 to-cyan-glow px-4 py-2 text-sm font-semibold text-white">
            <Activity className="h-4 w-4" /> {fps} FPS
          </span>
        </div>
      </Reveal>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Camera + status */}
        <div className="lg:col-span-2 space-y-6">
          <Reveal>
            <div className="relative">
              <CameraScan />
              <AnimatePresence mode="wait">
                <motion.div
                  key={distraction}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  className={`absolute bottom-3 left-1/2 -translate-x-1/2 rounded-full px-4 py-1.5 text-sm font-semibold ring-1 ${statusColor[driverStatus]}`}
                >
                  {distraction}
                </motion.div>
              </AnimatePresence>
            </div>
          </Reveal>

          {/* Metric cards */}
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3">
            {metrics.map((m, i) => (
              <Reveal key={m.label} delay={i * 0.05}>
                <div className="relative h-full overflow-hidden rounded-2xl glass p-4">
                  <div className="flex items-center justify-between">
                    <span className={`flex h-9 w-9 items-center justify-center rounded-lg ring-1 ${statusColor[m.status]}`}>
                      <m.icon className="h-4.5 w-4.5" />
                    </span>
                    <span className={`h-2 w-2 rounded-full ${statusDot[m.status]} ${m.status !== 'safe' ? 'animate-pulse' : ''}`} />
                  </div>
                  <p className="mt-3 text-xs text-[var(--text-muted)]">{m.label}</p>
                  <p className="font-display text-lg font-semibold">{m.value}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>

        {/* Right panel */}
        <div className="space-y-6">
          <Reveal delay={0.1}>
            <div className="rounded-2xl glass p-6">
              <div className="flex items-center gap-2 text-[var(--text-muted)]">
                <Gauge className="h-4.5 w-4.5" />
                <h3 className="font-display text-sm font-semibold uppercase tracking-wider">Driver Status</h3>
              </div>
              <div className="mt-4 flex items-center gap-3">
                <span className={`flex h-14 w-14 items-center justify-center rounded-2xl text-lg font-bold ring-1 ${statusColor[driverStatus]}`}>
                  {risk}
                </span>
                <div>
                  <p className="font-display text-xl font-semibold">{distraction}</p>
                  <p className="text-xs text-[var(--text-muted)]">Risk score · {risk > 60 ? 'High' : risk > 30 ? 'Moderate' : 'Low'}</p>
                </div>
              </div>
              {/* Risk bar */}
              <div className="mt-4 h-2 overflow-hidden rounded-full bg-[var(--border)]">
                <motion.div
                  className="h-full rounded-full"
                  style={{ background: risk > 60 ? 'linear-gradient(90deg,#ff5c7c,#ffc857)' : risk > 30 ? 'linear-gradient(90deg,#ffc857,#22e1ff)' : 'linear-gradient(90deg,#22d39a,#22e1ff)' }}
                  animate={{ width: `${risk}%` }}
                  transition={{ duration: 0.6 }}
                />
              </div>
            </div>
          </Reveal>

          <Reveal delay={0.15}>
            <div className="rounded-2xl glass p-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-xs text-[var(--text-muted)]">Confidence</p>
                  <p className="font-display text-2xl font-bold gradient-text">{confidence}%</p>
                </div>
                <div>
                  <p className="text-xs text-[var(--text-muted)]">FPS</p>
                  <p className="font-display text-2xl font-bold">{fps}</p>
                </div>
                <div>
                  <p className="text-xs text-[var(--text-muted)]">Trip Time</p>
                  <p className="font-display text-2xl font-bold">{mm}:{ss}</p>
                </div>
                <div>
                  <p className="text-xs text-[var(--text-muted)]">Risk Score</p>
                  <p className="font-display text-2xl font-bold">{risk}<span className="text-sm text-[var(--text-muted)]">/100</span></p>
                </div>
              </div>
            </div>
          </Reveal>

          <Reveal delay={0.2}>
            <div className="rounded-2xl glass p-6">
              <div className="flex items-center gap-2 text-[var(--text-muted)]">
                <Bell className="h-4.5 w-4.5" />
                <h3 className="font-display text-sm font-semibold uppercase tracking-wider">Alerts</h3>
              </div>
              <div className="mt-4 space-y-2.5">
                {sampleAlerts.map((a, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, x: -12 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.08 }}
                    className="flex items-center gap-3 rounded-xl bg-[var(--bg-elev)]/40 px-3 py-2.5"
                  >
                    {a.level === 'safe' ? <CheckCircle2 className="h-4 w-4 text-success" /> : <AlertTriangle className={`h-4 w-4 ${a.level === 'danger' ? 'text-danger' : 'text-warning'}`} />}
                    <span className="flex-1 text-sm">{a.type}</span>
                    <span className="text-xs text-[var(--text-muted)]">{a.time}</span>
                  </motion.div>
                ))}
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </div>
  );
}
